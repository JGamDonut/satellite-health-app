export const satellite = () => {
  console.log('look  ');
};

document.addEventListener('DOMContentLoaded', function() {
  satellite();
});

